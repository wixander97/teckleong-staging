Send instant notification messages to the user in live.

This technical module allows you to send instant notification messages from the server to the user in live.
Two kinds of notification are supported.

* Success: Displayed in a `success` theme color flying popup div
* Danger: Displayed in a `danger` theme color flying popup div
* Warning: Displayed in a `warning` theme color flying popup div
* Information: Displayed in a `info` theme color flying popup div
* Default: Displayed in a `default` theme color flying popup div
